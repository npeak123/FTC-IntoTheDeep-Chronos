package org.firstinspires.ftc.teamcode;


import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;


import org.firstinspires.ftc.teamcode.Subsystems.Intake;
import org.firstinspires.ftc.teamcode.Subsystems.ArmConfig;

@TeleOp(name = Constants.OpModes.teleop, group = Constants.OpModes.linearOp)
public class RobotTeleOp extends OpMode {

    Mecanum s_Drivetrain;
    Intake s_Intake;

    private ElapsedTime runtime = new ElapsedTime();

    boolean slomode = false;

    @Override
    public void init() {
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        s_Drivetrain = new Mecanum(hardwareMap);
        try {
            s_Intake = new Intake(hardwareMap);
        } catch (Exception e) {

        }
        runtime.reset();

    }

    public void loop() {



        if (gamepad2.left_bumper) {
            slomode = true;
        } else if (gamepad2.right_bumper) {
            slomode = false;
        }


        s_Drivetrain.teleop(gamepad1, slomode);
        try {
            s_Intake.teleop(gamepad1, gamepad2);
        } catch (Exception e) {
        }
        s_Drivetrain.periodic(telemetry);
        try {
            s_Intake.periodic(telemetry);
        } catch (Exception e) {

        }

        telemetry.addData("Status", "Run Time: " + runtime.toString());
        telemetry.update();

    }
}

