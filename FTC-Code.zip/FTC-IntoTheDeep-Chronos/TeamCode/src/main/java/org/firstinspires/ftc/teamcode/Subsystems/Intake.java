package org.firstinspires.ftc.teamcode.Subsystems;

import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.Constants;

public class Intake{
    Servo armExtender;
    CRServo intake;

    int armE = 0;
    boolean intakeOn = false;
    boolean intakeShoot =  false;

    public Intake(HardwareMap hardwareMap) {
        armExtender = hardwareMap.get(Servo.class, Constants.ClawConstants.armExtender);
        intake = hardwareMap.get(CRServo.class, Constants.ClawConstants.intake);

        armExtender.setDirection(Constants.ClawConstants.invertL);

        contract();

    }

    public void teleop(Gamepad gamepad1, Gamepad gamepad2) {

        if (armE == 0) {
            if (gamepad2.a) {
                extend();
                armE = 1;
            }
        } else {
            if (gamepad2.y) {
                contract();
                armE = 0;
            }
        }

        if(intakeOn) {
            if (gamepad1.b) {
                stop();
                intakeOn = false;
            }
        } else if (!intakeOn) {
            if (gamepad1.a) {
                intakeOn = true;
                takeIn();
            }
            if (!intakeShoot) {
                if(gamepad1.x) {
                    shoot();
                    intakeShoot = true;
                }
            } else if (intakeShoot) {
                if (gamepad1.y) {
                    stop();
                    intakeShoot = false;
                }
            }
        }
    }

    public void extend() {
        armExtender.setPosition(Constants.ClawConstants.extendedAngle);
    }

    public void contract() {
        armExtender.setPosition(Constants.ClawConstants.contractedAngle);
    }

    public void takeIn () {
        intake.setPower(-1);
    }

    public void stop () {
        intake.setPower(0);
    }

    public void shoot () {
        intake.setPower(1);
        }

       public void periodic(Telemetry telemetry) {
        telemetry.addLine("Intake:");
    }

    }

